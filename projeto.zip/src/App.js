import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Manual from './pages/Manual';
import Automacao from './pages/Automacao';

const App = () => (
  <Router>
    <Header />
    <Routes>
      <Route path="/manual" element={<Manual />} />
      <Route path="/automacao" element={<Automacao />} />
    </Routes>
  </Router>
);

export default App;
