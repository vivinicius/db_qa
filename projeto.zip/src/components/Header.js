import React from 'react';
import { Link } from 'react-router-dom';
import './Header.css';

const Header = () => (
  <header className="header">
    <h1>Apostila de Testes</h1>
    <nav className="nav">
      <Link to="/manual">Manual</Link>
      <Link to="/automacao">Automação</Link>
    </nav>
    <div className="corner-text">
      <small>&lt;db&gt;</small>
    </div>
  </header>
);

export default Header;
