const Parte1 = {
    id: 2,
    title: 'Automação de Front-End',
    content: `
      <h3>Ferramentas Necessárias:</h3>
      <ul>
        <li>Java</li>
        <li>Selenium WebDriver</li>
        <li>Maven</li>
        <li>IDE (Eclipse, IntelliJ IDEA ou VS Code)</li>
        <li>ChromeDriver (ou o driver do navegador de sua preferência)</li>
        <li>Cucumber</li>
      </ul>
  
      <h3>Conceitos Iniciais:</h3>
      <ul>
        <li>O que é automação de testes?</li>
        <li>Estrutura de um projeto de automação.</li>
        <li>Configurando o ambiente.</li>
      </ul>
  
      <h3>Estrutura de Pastas no Projeto:</h3>
      <pre>
      src/main/java: Contém o código-fonte principal.
      src/test/java: Contém os testes automatizados.
      src/test/resources: Contém arquivos de configuração e dados de teste, incluindo os arquivos .feature do Cucumber.
      target: Diretório gerado pelo Maven, onde ficam os relatórios e resultados de build.
      pom.xml: Arquivo de configuração do Maven, onde são declaradas as dependências.
      </pre>
  
      <h3>Exemplo:</h3>
      <pre>
      meu-projeto-automacao/
      ├── src
      │   ├── main
      │   │   └── java
      │   │       └── br.com.projeto
      │   │           └── paginas
      │   ├── test
      │   │   └── java
      │   │       └── br.com.projeto
      │   │           └── testes
      │   └── test
      │       └── resources
      │           └── features
      ├── pom.xml
      └── target
      </pre>
  
      <h3>Exercício 1: Configurando o Ambiente</h3>
      <ol>
        <li>Crie um projeto Maven.</li>
        <li>Adicione as dependências do Selenium e Cucumber no pom.xml.</li>
        <li>Configure o ChromeDriver no projeto.</li>
      </ol>
      <pre>
      <code>
      <dependencies>
          <dependency>
              <groupId>org.seleniumhq.selenium</groupId>
              <artifactId>selenium-java</artifactId>
              <version>4.10.0</version>
          </dependency>
          <dependency>
              <groupId>io.cucumber</groupId>
              <artifactId>cucumber-java</artifactId>
              <version>7.11.0</version>
          </dependency>
          <dependency>
              <groupId>io.cucumber</groupId>
              <artifactId>cucumber-junit</artifactId>
              <version>7.11.0</version>
          </dependency>
      </dependencies>
      </code>
      </pre>
  
      <h3>Exercício 2: Primeiro Teste Automático com Cucumber</h3>
      <p>Crie um arquivo <strong>.feature</strong> em <strong>src/test/resources/features</strong> com o seguinte conteúdo:</p>
      <pre>
      <code>
      Feature: Login no Sauce Demo
  
        Scenario: Realizar login com sucesso
          Given que estou na página inicial
          When eu insiro o usuário "standard_user" e senha "secret_sauce"
          And clico no botão de login
          Then devo ser redirecionado para a página de produtos
      </code>
      </pre>
  
      <p>Crie uma classe de execução do Cucumber:</p>
      <pre>
      <code>
      import org.junit.runner.RunWith;
      import io.cucumber.junit.Cucumber;
      import io.cucumber.junit.CucumberOptions;
  
      @RunWith(Cucumber.class)
      @CucumberOptions(features = "src/test/resources/features", glue = "br.com.projeto.testes")
      public class RunnerTest {
      }
      </code>
      </pre>
  
      <p>Implemente os steps do cenário:</p>
      <pre>
      <code>
      import org.openqa.selenium.By;
      import org.openqa.selenium.WebDriver;
      import org.openqa.selenium.chrome.ChromeDriver;
      import io.cucumber.java.en.*;
  
      public class LoginSteps {
  
          WebDriver driver;
  
          @Given("que estou na página inicial")
          public void queEstouNaPaginaInicial() {
              driver = new ChromeDriver();
              driver.get("https://www.saucedemo.com");
          }
  
          @When("eu insiro o usuário {string} e senha {string}")
          public void euInsiroOUsuarioESenha(String usuario, String senha) {
              driver.findElement(By.id("user-name")).sendKeys(usuario);
              driver.findElement(By.id("password")).sendKeys(senha);
          }
  
          @And("clico no botão de login")
          public void clicoNoBotaoDeLogin() {
              driver.findElement(By.id("login-button")).click();
          }
  
          @Then("devo ser redirecionado para a página de produtos")
          public void devoSerRedirecionadoParaAPaginaDeProdutos() {
              String urlAtual = driver.getCurrentUrl();
              Assert.assertTrue(urlAtual.contains("inventory.html"));
              driver.quit();
          }
      }
      </code>
      </pre>
  
      <h3>Exercício 3: Adicionar Cenários no Gherkin</h3>
      <p>Adicione mais cenários ao arquivo <strong>.feature</strong> para validar diferentes comportamentos, como login inválido e logout.</p>
    `,
  };
  
  export default Parte1;
  