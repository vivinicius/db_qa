const Introducao = {
    id: 1,
    title: 'Introdução',
    content: `
      <p> Bem-vindo(a) à apostila de estudos de automação de testes! 
      Este material foi criado para ajudar você a desenvolver competências em automação de testes <strong>front-end</strong> e <strong>back-end.</strong>
      Utilizaremos o site <strong>Sauce Demo para automação de front-end</strong> e a <strong>API Cat Facts para automação de testes de API.</strong> </p>
  
      <p> A apostila está estruturada para que você evolua gradualmente, aprendendo novos conceitos e técnicas enquanto pratica exercícios. </p>
    `,
  };
  
  export default Introducao;