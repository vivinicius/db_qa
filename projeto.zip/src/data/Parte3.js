const Parte3 = {
  id: 4,
  title: 'Integração de Front-End e API',
  content: `
    <p>Nesta seção, você aprenderá como combinar dados retornados de uma API para validar elementos no front-end.</p>
    <h3>Exercícios:</h3>
    <ol>
      <li>Usar os dados retornados da API Cat Facts para validar informações na página de produtos do Sauce Demo.</li>
      <li>Criar testes para verificar se os dados exibidos no front-end correspondem aos valores da API.</li>
    </ol>
  `,
};

export default Parte3;
