import React from 'react';

const Manual = () => (
  <div>
    <h1>Página Manual</h1>
    <p>Conteúdo não disponível no momento.</p>
  </div>
);

export default Manual;
