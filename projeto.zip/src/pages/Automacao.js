import React, { useState } from 'react';
import Introducao from '../data/Introducao';
import Parte1 from '../data/Parte1';
import Parte2 from '../data/Parte2';
import Parte3 from '../data/Parte3';
import Parte4 from '../data/Parte4';
import './Automacao.css';

const sections = [Introducao, Parte1, Parte2, Parte3, Parte4];

const Automacao = () => {
  const [expanded, setExpanded] = useState(1); // Botão 1 expandido por padrão

  const toggleSection = (id) => {
    setExpanded((prev) => (prev === id ? null : id));
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'row', height: '100vh' }}>
      {/* Botões à esquerda */}
      <div className="automacao-sidebar">
        {sections.map((section) => (
          <button
            key={section.id}
            onClick={() => toggleSection(section.id)}
            className="automacao-button"
            style={{
              backgroundColor: expanded === section.id ? '#3f8c94' : '#fff', // Cor para o botão ativo
            }}
          >
            {section.title}
          </button>
        ))}
      </div>

      {/* Conteúdo à direita */}
      <div style={{ flex: 1, padding: '2rem', backgroundColor: '#fff' }}>
        {sections.map((section) => (
          <div
            key={section.id}
            className={`automacao-content ${expanded === section.id ? 'open' : ''}`}
          >
            <div
              className="automacao-content-inner"
              dangerouslySetInnerHTML={{ __html: section.content }}
            />
          </div>
        ))}
      </div>
    </div>
  );
};

export default Automacao;
